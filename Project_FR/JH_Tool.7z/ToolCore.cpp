#include "pch.h"
#include "ToolCore.h"
void ToolCore::MapFlatting()
{
	HQuadTree* pQuadTree = I_MapMgr.GetCurrentQuadTree().get();
	JH_Node* pNode = nullptr;
	JH_Map*  pMap = nullptr;


	pQuadTree->FindSelectPoint();


	m_Sphere.vCenter = I_Select.m_vIntersection;

	if (pQuadTree->m_SelectNodeList.size() <= 0)return ;
	pNode = pQuadTree->m_SelectNodeList[0];
	//���� ������ �Ÿ��� �ִ� ������ �ø� 
	float fDistance;

	if (pNode == nullptr)return ;
	DWORD dwFace = pNode->m_IndexList.size() / 3;

	for (int iFace = 0; iFace < dwFace; iFace++)
	{
		for (int iV = 0; iV < 3; iV++)
		{
			DWORD i0 = pNode->m_IndexList[iFace * 3 + iV];


			fDistance = D3DXVec3Length(&D3DXVECTOR3(m_Sphere.vCenter - pQuadTree->m_pMap->m_VertexData[i0].p));

			//�ڻ����Լ��� �̿��Ͽ� �������� �ø�
			float  fDet = (fDistance / m_Sphere.Radius)*D3DX_PI / 2.0;

			float value = cos(fDet)*g_SecondPerFrame;
			if (m_Sphere.Radius > fDistance)
			{
				pQuadTree->m_pMap->MapFlatting(i0);


				//NorMalUpdate
				DWORD i0 = pNode->m_IndexList[iFace * 3 + 0];
				DWORD i1 = pNode->m_IndexList[iFace * 3 + 1];
				DWORD i2 = pNode->m_IndexList[iFace * 3 + 2];

				D3DXVECTOR3 vFaceNormal, E0, E1;
				E0 = pQuadTree->m_pMap->m_VertexData[i1].p - pQuadTree->m_pMap->m_VertexData[i0].p;
				E1 = pQuadTree->m_pMap->m_VertexData[i2].p - pQuadTree->m_pMap->m_VertexData[i0].p;

				D3DXVec3Cross(&vFaceNormal, &E0, &E1);
				D3DXVec3Normalize(&vFaceNormal, &vFaceNormal);

				pQuadTree->m_pMap->m_VertexData[i0].n = vFaceNormal;
				pQuadTree->m_pMap->m_VertexData[i1].n = vFaceNormal;
				pQuadTree->m_pMap->m_VertexData[i2].n = vFaceNormal;
			}


		}

	}
	DX::GetContext()->UpdateSubresource(pQuadTree->m_pMap->m_dxHelper.GetVertexBuffer(), 0, 0, &pQuadTree->m_pMap->m_VertexData.at(0), 0, 0);

	return ;
}
bool ToolCore::MapUpDown()
{
	HQuadTree* pQuadTree = I_MapMgr.GetCurrentQuadTree().get();
	JH_Node* pNode = nullptr;
	JH_Map*  pMap = nullptr;


	pQuadTree->FindSelectPoint();


	m_Sphere.vCenter = I_Select.m_vIntersection;

	if (pQuadTree->m_SelectNodeList.size() <= 0)return false;
	pNode = pQuadTree->m_SelectNodeList[0];
	//���� ������ �Ÿ��� �ִ� ������ �ø� 
	float fDistance;

	if (pNode == nullptr)return false;
	DWORD dwFace = pNode->m_IndexList.size() / 3;

	for (int iFace = 0; iFace < dwFace; iFace++)
	{
		for (int iV = 0; iV < 3; iV++)
		{
			DWORD i0 = pNode->m_IndexList[iFace * 3 + iV];


			fDistance = D3DXVec3Length(&D3DXVECTOR3(m_Sphere.vCenter - pQuadTree->m_pMap->m_VertexData[i0].p));

			//�ڻ����Լ��� �̿��Ͽ� �������� �ø�
			float  fDet = (fDistance / m_Sphere.Radius)*D3DX_PI / 2.0;

			float value = cos(fDet)*g_SecondPerFrame;
			if (m_Sphere.Radius > fDistance)
			{
				pQuadTree->m_pMap->MapUpDown(i0, value);


				//NorMalUpdate
				DWORD i0 = pNode->m_IndexList[iFace * 3 + 0];
				DWORD i1 = pNode->m_IndexList[iFace * 3 + 1];
				DWORD i2 = pNode->m_IndexList[iFace * 3 + 2];

				D3DXVECTOR3 vFaceNormal, E0, E1;
				E0 = pQuadTree->m_pMap->m_VertexData[i1].p - pQuadTree->m_pMap->m_VertexData[i0].p;
				E1 = pQuadTree->m_pMap->m_VertexData[i2].p - pQuadTree->m_pMap->m_VertexData[i0].p;

				D3DXVec3Cross(&vFaceNormal, &E0, &E1);
				D3DXVec3Normalize(&vFaceNormal, &vFaceNormal);

				pQuadTree->m_pMap->m_VertexData[i0].n = vFaceNormal;
				pQuadTree->m_pMap->m_VertexData[i1].n = vFaceNormal;
				pQuadTree->m_pMap->m_VertexData[i2].n = vFaceNormal;
			}


		}

	}
	DX::GetContext()->UpdateSubresource(pQuadTree->m_pMap->m_dxHelper.GetVertexBuffer(), 0, 0, &pQuadTree->m_pMap->m_VertexData.at(0), 0, 0);

	return true;
}
bool ToolCore::MapSplatting()
{

	I_MapMgr.GetCurrentQuadTree()->FindSelectPoint();
	if (I_MapMgr.GetCurrentQuadTree()->m_SelectNodeList.size() <= 0)return false;
	m_Sphere.vCenter = I_Select.m_vIntersection;

	//������ǥ�� �ؽ��� ��ǥ uv ������ ����
	m_CSBuf.vPickPos = D3DXVECTOR3(m_Sphere.vCenter.x + ((m_CSBuf.iRow) / 2.0f),
		0, -(m_Sphere.vCenter.z) + ((m_CSBuf.iCol) / 2.0f));
	//����ü���� ����
	DX::GetContext()->UpdateSubresource((ID3D11Resource*)m_CS.m_pStructureBF.Get(), NULL, nullptr, &m_CSBuf, NULL, NULL);
	// ComputeShaderExcute ������׷��� �������� ��ŭ ������
	m_CS.RunComputeShaderSplatting(m_CSBuf.iRow / 16, m_CSBuf.iCol / 16, 1);
	
	return true;
}
bool ToolCore::Init()
{


	m_pMainCamera->CreateViewMatrix(D3DXVECTOR3(0, 0, -50.0f), D3DXVECTOR3(0, 0, 0));
	m_pMainCamera->UpdateBasisVector();


	float fAspect = (float)g_rtClient.right / g_rtClient.bottom;
	m_pMainCamera->CreateProjMatrix(1.0F, 10000.0F, D3DX_PI*0.5, fAspect);

	m_DebugLine.Create(DX::GetDevice().Get(), DX::GetContext().Get(), L"../../data/shader/LineShader.txt", nullptr);
	I_LIGHT_MGR.Create(L"../../data/shader/LightShader.txt",L"../../data/LightSrc/LightInfo.txt");
	return true;
}
bool ToolCore::Frame()
{

	I_LIGHT_MGR.Frame();
	I_LIGHT_MGR.m_cbLight.vEyeDir[0] = { m_pMainCamera->m_vLookup,30 };
	I_LIGHT_MGR.m_cbLight.vEyePos[0] = { m_pMainCamera->m_vPos,30 };


	I_MapMgr.Frame();
	I_ObjMgr.Frame();

	m_DebugLine.SetMatrix(nullptr, &m_pMainCamera->m_matView, &m_pMainCamera->m_matProj);

	switch (m_eState)
	{
		case TOOLSTATE::HEIGHT:
		{
			if(G_Input.KeyCheck(VK_LBUTTON))
			MapUpDown();
			break;
		}
		case TOOLSTATE::SPLATTING:
		{
			if (G_Input.KeyCheck(VK_LBUTTON))
			MapSplatting();
			break;
		}
		case TOOLSTATE::FLATTING:
		{
			if (G_Input.KeyCheck(VK_LBUTTON))
				MapFlatting();
			break;
		}
		default:
			break;
		}
	return true;
}
bool ToolCore::Render()
{

	I_MapMgr.Render();
	I_ObjMgr.Render();

	m_DebugLine.Draw(D3DXVECTOR3(0, 0, 0), D3DXVECTOR3(100, 0, 0), D3DXVECTOR4(1, 0, 0, 1));
	m_DebugLine.Draw(D3DXVECTOR3(0, 0, 0), D3DXVECTOR3(0, 100, 0), D3DXVECTOR4(0, 1, 0, 1));
	m_DebugLine.Draw(D3DXVECTOR3(0, 0, 0), D3DXVECTOR3(0, 0, 100), D3DXVECTOR4(0, 0, 1, 1));
	return true;
}
bool ToolCore::Release()
{
	return true;
}


