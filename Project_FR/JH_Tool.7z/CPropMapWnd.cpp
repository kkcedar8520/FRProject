﻿// CPropMapWnd.cpp: 구현 파일
//
#pragma 
#include "stdafx.h"
#include "JH_Tool.h"
#include "CPropMapWnd.h"


// CPropMapWnd

IMPLEMENT_DYNAMIC(CPropMapWnd, CDockablePane)

CPropMapWnd::CPropMapWnd()
{

}

CPropMapWnd::~CPropMapWnd()
{
}


BEGIN_MESSAGE_MAP(CPropMapWnd, CDockablePane)
END_MESSAGE_MAP()



// CPropMapWnd 메시지 처리기


#include"pch.h"