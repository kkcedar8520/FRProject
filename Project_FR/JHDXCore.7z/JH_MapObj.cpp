#include "JH_MapObj.h"

namespace JH {

	JH_MapObj::JH_MapObj()
	{
		m_iQuadIndex = -1;
		m_ID = -1;
	}


	JH_MapObj::~JH_MapObj()
	{
	}
}