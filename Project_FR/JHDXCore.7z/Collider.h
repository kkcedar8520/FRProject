#pragma once
#include"JH_DXStd.h"
class Collider
{
public:
	CreateBox();
};

