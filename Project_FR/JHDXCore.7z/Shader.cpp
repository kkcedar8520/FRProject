#include "Shader.h"


void Shader::SetVertexShader(const std::string ShaderFile, const std::string functionName)
{
	
}
void Shader::SetPixelShader(const std::string ShaderFile, const std::string functionName)
{

}