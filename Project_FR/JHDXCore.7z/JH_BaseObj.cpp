#include "JH_BaseObj.h"



JH_BaseObj::JH_BaseObj()
{
	D3DXMatrixIdentity(&m_matWorld);
}


JH_BaseObj::~JH_BaseObj()
{
}
