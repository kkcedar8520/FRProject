#include "JH_ObjMgr.h"


	void JH_ObjMgr::AddObject(std::shared_ptr<JH_Obj> Obj)
	{
		m_ObjectList.insert(std::make_pair(Obj->GetID(), Obj));
	}
	int JH_ObjMgr::CreateObject(const std::string file)
	{
	
		shared_ptr<JH_Obj> pObj = make_shared<JH_Obj>();

		if (!pObj->ReadFile(file)) { return -1;}
		m_ID++;

		pObj->SetID(m_ID);
		m_ObjectList.insert(std::make_pair(pObj->GetID(), pObj));
		
		return m_ID;
	}
	JH_Obj* JH_ObjMgr::FindObjectByIndex(int Index)
	{
		ObjIter Iter;
		Iter =m_ObjectList.find(Index);

		if (Iter != m_ObjectList.end())
		return Iter->second.get();

		return nullptr;
	}
	void JH_ObjMgr::SetCamera(int Index, JHCamera* Camera)
	{
		JH_Obj* Obj=FindObjectByIndex(Index);
		if (Obj != nullptr)
			Obj->SetCamera(Camera);
	}
	bool JH_ObjMgr::Frame()
	{
		
		for (auto Obj : m_DrawObjectList)
		{
			Obj->Frame();
		}
		return true;
	}
	bool JH_ObjMgr::Render()
	{
		for (auto Obj : m_DrawObjectList)
		{
			Obj->Render();
		}
		return true;
	}
	JH_ObjMgr::JH_ObjMgr()
	{
	}


	JH_ObjMgr::~JH_ObjMgr()
	{
		for(auto iter : m_ObjectList)
		{
			iter.second = nullptr;
		}
	}
