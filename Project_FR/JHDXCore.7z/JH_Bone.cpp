#include "JH_Bone.h"

JH_Bone::JH_Bone()
{

}
JH_Bone::~JH_Bone()
{

}